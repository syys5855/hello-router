import Vue from 'vue';
export default Vue.component('foo', {
    template: `<div>foo</div>`
});