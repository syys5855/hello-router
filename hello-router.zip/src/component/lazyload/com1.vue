<template>
  <h3 class="text-success">hahhah lazyload com1</h3>
  
</template>

<script>
export default {

}
</script>

<style>

</style>
